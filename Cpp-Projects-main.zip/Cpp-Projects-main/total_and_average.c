#include <stdio.h>
void main()
{
    float total=0;float avg=0;int n;
    int x[50];
    printf("Enter the number of array elements:\t");
    scanf("%d",&n);
    printf("Enter Array elements:");
    for(int i=0;i<n;i++)
    {
        scanf("%d",&x[i]);
        total +=x[i];
    }
    avg = total/n;
    printf("%f",total);
    printf("%f",avg);
    //return 0;
}