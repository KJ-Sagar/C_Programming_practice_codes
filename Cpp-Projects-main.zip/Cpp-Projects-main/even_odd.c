#include<stdio.h>
void main()
{
   int x[10]={10,20,32,55,40,87,90,100,130,111};
   int i=0,n=10,ec=0,oc=0;
   for(i=0;i<n;i++)
   {
    if(x[i]%2==0)
    {
       // printf("%d",x[i]);
        ec++;
    }
    else
    {
        //printf("%d",x[i]);
        oc++;
    }
   } 
   printf("The number of odd numbers are : %d",oc);
   printf("The number of even numbers are : %d",ec);

}