#include<stdio.h>
void main()
{
   int arr[10]={10, 20,30,50,40,80,90,100,130,111};
    int big=0;
    for(int i=0;i<10;i++)
    {
        if(arr[i]>big)
        {
            big=arr[i];
        }
    }
    printf("The largest element is %d",big);
}